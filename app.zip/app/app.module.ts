import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {
  RichTextEditorModule, ToolbarService, TableService, QuickToolbarService,
  LinkService, ImageService, HtmlEditorService, MarkdownEditorService
} from '@syncfusion/ej2-angular-richtexteditor';
import { ReactiveFormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RichTextEditorModule,
    ReactiveFormsModule
  ],
  providers: [RichTextEditorModule, ToolbarService, TableService, QuickToolbarService,
    LinkService, ImageService, HtmlEditorService, MarkdownEditorService],
  bootstrap: [AppComponent]
})
export class AppModule { }
