import { Component, OnInit, ViewChild } from '@angular/core';
import { RichTextEditorComponent } from '@syncfusion/ej2-angular-richtexteditor';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'imaadEmail2';
  public mode: string = 'Markdown';
  // emailForm: FormGroup;

  // @ViewChild('fromRTE')
  //   constructor(private fb: FormBuilder) {
  //   // <--- inject FormBuilder
  // }

  // ngOnInit(): void {
  //   this.emailForm = new FormGroup({
  //     'name': new FormControl(null, Validators.required)
  //   });
  // }

  // rteCreated(): void {
  //   this.rteEle.element.focus();
  // }

  onSubmit(): void {
    alert('Form submitted successfully');
  }

  public tools: object = {
    items: [
      'Bold', 'Italic', 'Underline', 'StrikeThrough', '|',
      'FontName', 'FontSize', 'FontColor', 'BackgroundColor', '|',
      'LowerCase', 'UpperCase', '|', 'Undo', 'Redo', '|',
      'Formats', 'Alignments', '|', 'OrderedList', 'UnorderedList', '|',
      'Indent', 'Outdent', '|', 'CreateLink', 'CreateTable',
      'Image', '|', 'ClearFormat', 'Print', 'SourceCode', '|', 'FullScreen']
  };
}
